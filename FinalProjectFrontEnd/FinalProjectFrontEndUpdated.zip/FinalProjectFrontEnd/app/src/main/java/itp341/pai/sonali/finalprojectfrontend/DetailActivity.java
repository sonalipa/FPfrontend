package itp341.pai.sonali.finalprojectfrontend;

/**
 * Created by Sonali Pai on 11/10/2017.
 */

public class DetailActivity {
}
