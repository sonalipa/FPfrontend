package itp341.pai.sonali.finalprojectfrontend;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Window;

public class AddToiletActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addtoilet);
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//
//        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#000000"));
//        getSupportActionBar().setBackgroundDrawable(colorDrawable);
//
//        Window window = this.getWindow();
//
//// finally change the color
//        window.setStatusBarColor(getResources().getColor(android.R.color.black));
    }

}
